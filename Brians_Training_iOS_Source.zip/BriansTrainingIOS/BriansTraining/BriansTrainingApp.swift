import SwiftUI

@main
struct BriansTrainingApp: App {
    @StateObject private var store = TrainingStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
        }
    }
}