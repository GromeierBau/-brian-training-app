import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var store: TrainingStore
    @State private var selectedDay: TrainingDay?

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                nextWorkoutCard

                ForEach(store.plan) { day in
                    Button {
                        selectedDay = day
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(day.name)
                                    .font(.headline)
                                    .foregroundStyle(.primary)
                                Text("\(day.exercises.count) Übungen")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundStyle(.secondary)
                        }
                        .padding()
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding()
        }
        .navigationTitle("Brians Training")
        .fullScreenCover(item: $selectedDay) { day in
            WorkoutView(day: day)
        }
    }

    private var nextWorkoutCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("NÄCHSTER TRAININGSTAG")
                .font(.caption.bold())
                .foregroundStyle(.red)
            Text(store.nextDay.name)
                .font(.system(size: 28, weight: .bold))
            Text("\(store.nextDay.exercises.count) Übungen")
                .foregroundStyle(.secondary)
            Button {
                selectedDay = store.nextDay
            } label: {
                Label("Training starten", systemImage: "play.fill")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
            }
            .buttonStyle(.borderedProminent)
            .tint(.red)
        }
        .padding()
        .background(
            LinearGradient(colors: [.black, .gray.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 22)
        )
        .foregroundStyle(.white)
    }
}