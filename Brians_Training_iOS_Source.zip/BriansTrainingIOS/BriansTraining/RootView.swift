import SwiftUI

struct RootView: View {
    @EnvironmentObject private var store: TrainingStore

    var body: some View {
        TabView {
            NavigationStack {
                HomeView()
            }
            .tabItem { Label("Start", systemImage: "house.fill") }

            NavigationStack {
                HistoryView()
            }
            .tabItem { Label("Verlauf", systemImage: "clock.arrow.circlepath") }

            NavigationStack {
                RecordsView()
            }
            .tabItem { Label("Rekorde", systemImage: "trophy.fill") }

            NavigationStack {
                SettingsView()
            }
            .tabItem { Label("Mehr", systemImage: "gearshape.fill") }
        }
        .tint(.red)
    }
}