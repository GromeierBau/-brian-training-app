import SwiftUI

struct HistoryView: View {
    @EnvironmentObject private var store: TrainingStore

    var body: some View {
        List {
            if store.history.isEmpty {
                ContentUnavailableView(
                    "Noch keine Trainings",
                    systemImage: "figure.strengthtraining.traditional",
                    description: Text("Deine gespeicherten Einheiten erscheinen hier.")
                )
            } else {
                ForEach(store.history.reversed()) { workout in
                    NavigationLink {
                        WorkoutDetailView(workout: workout)
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(workout.dayName).font(.headline)
                            Text(workout.date.formatted(date: .abbreviated, time: .shortened))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .navigationTitle("Verlauf")
    }
}

private struct WorkoutDetailView: View {
    let workout: WorkoutLog

    var body: some View {
        List {
            ForEach(workout.exercises) { exercise in
                Section(exercise.exerciseName) {
                    ForEach(Array(exercise.sets.enumerated()), id: \.element.id) { index, set in
                        HStack {
                            Text("Satz \(index + 1)")
                            Spacer()
                            Text("\(set.weight.formatted()) kg × \(set.reps)")
                        }
                    }
                    if !exercise.note.isEmpty {
                        Text(exercise.note).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .navigationTitle(workout.dayName)
    }
}