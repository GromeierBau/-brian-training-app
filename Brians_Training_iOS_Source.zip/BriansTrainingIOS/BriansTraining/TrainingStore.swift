import Foundation

@MainActor
final class TrainingStore: ObservableObject {
    @Published var plan: [TrainingDay] = TrainingStore.defaultPlan
    @Published var history: [WorkoutLog] = []
    @Published var nextDayIndex: Int = 0

    private let historyURL: URL
    private let stateURL: URL

    init() {
        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        historyURL = directory.appendingPathComponent("training_history.json")
        stateURL = directory.appendingPathComponent("training_state.json")
        load()
    }

    var nextDay: TrainingDay {
        plan[nextDayIndex % plan.count]
    }

    func complete(_ log: WorkoutLog) {
        history.append(log)
        nextDayIndex = ((plan.firstIndex(where: { $0.id == log.dayID }) ?? nextDayIndex) + 1) % plan.count
        save()
    }

    func lastLog(for exercise: Exercise) -> ExerciseLog? {
        history.reversed()
            .compactMap { $0.exercises.first(where: { $0.exerciseID == exercise.id || $0.exerciseName == exercise.name }) }
            .first
    }

    func bestSet(for name: String) -> CompletedSet? {
        history
            .flatMap(\.exercises)
            .filter { $0.exerciseName == name }
            .flatMap(\.sets)
            .max { estimatedOneRepMax($0) < estimatedOneRepMax($1) }
    }

    private func estimatedOneRepMax(_ set: CompletedSet) -> Double {
        set.weight * (1 + Double(set.reps) / 30.0)
    }

    func reset() {
        history = []
        nextDayIndex = 0
        save()
    }

    private func load() {
        if let data = try? Data(contentsOf: historyURL),
           let decoded = try? JSONDecoder.training.decode([WorkoutLog].self, from: data) {
            history = decoded
        }
        if let data = try? Data(contentsOf: stateURL),
           let decoded = try? JSONDecoder().decode(Int.self, from: data) {
            nextDayIndex = decoded
        }
    }

    private func save() {
        if let data = try? JSONEncoder.training.encode(history) {
            try? data.write(to: historyURL, options: .atomic)
        }
        if let data = try? JSONEncoder().encode(nextDayIndex) {
            try? data.write(to: stateURL, options: .atomic)
        }
    }

    static let defaultPlan: [TrainingDay] = [
        TrainingDay(name: "Tag 1 – Brust + Bizeps", exercises: [
            Exercise(name: "Brustpresse", muscle: "Brust, vordere Schulter, Trizeps", targetSets: 4, targetReps: "8–12"),
            Exercise(name: "Schrägbank-Brustpresse", muscle: "Obere Brust, Schulter", targetSets: 3, targetReps: "8–12"),
            Exercise(name: "Butterfly", muscle: "Brust", targetSets: 3, targetReps: "12–15"),
            Exercise(name: "Scott-Curls", muscle: "Bizeps", targetSets: 3, targetReps: "10–12"),
            Exercise(name: "Hammercurls", muscle: "Bizeps, Unterarm", targetSets: 3, targetReps: "10–12")
        ]),
        TrainingDay(name: "Tag 2 – Rücken + Trizeps", exercises: [
            Exercise(name: "Hammer Strength Lat Pulldown", muscle: "Latissimus, oberer Rücken, Bizeps", targetSets: 4, targetReps: "8–12", imageName: "lat_pulldown.jpg"),
            Exercise(name: "Star Trac Row", muscle: "Mittlerer Rücken, Latissimus, Bizeps", targetSets: 4, targetReps: "8–12", imageName: "row.jpg"),
            Exercise(name: "Cybex VR3 Row", muscle: "Oberer und mittlerer Rücken", targetSets: 3, targetReps: "10–12", imageName: "cybex_row.jpg"),
            Exercise(name: "Reverse Butterfly", muscle: "Hintere Schulter, oberer Rücken", targetSets: 3, targetReps: "12–15", imageName: "reverse_butterfly.jpg"),
            Exercise(name: "Trizepsdrücken", muscle: "Trizeps", targetSets: 3, targetReps: "10–15"),
            Exercise(name: "Überkopf-Trizeps", muscle: "Langer Trizepskopf", targetSets: 3, targetReps: "10–12")
        ]),
        TrainingDay(name: "Tag 3 – Beine + Bauch", exercises: [
            Exercise(name: "Cybex Squat Press", muscle: "Quadrizeps, Gesäß, Beinbeuger", targetSets: 4, targetReps: "8–12", imageName: "squat_press.jpg"),
            Exercise(name: "Leg Extension", muscle: "Quadrizeps", targetSets: 3, targetReps: "10–12", imageName: "leg_extension.jpg"),
            Exercise(name: "Seated Leg Curl", muscle: "Hintere Oberschenkel", targetSets: 3, targetReps: "10–12", imageName: "leg_curl.jpg"),
            Exercise(name: "Wadenheben", muscle: "Waden", targetSets: 4, targetReps: "12–15", imageName: "calf_raise.jpg"),
            Exercise(name: "Bauch", muscle: "Bauch", targetSets: 3, targetReps: "12–20")
        ]),
        TrainingDay(name: "Tag 4 – Schultern + Arme", exercises: [
            Exercise(name: "Schulterpresse", muscle: "Schultern, Trizeps", targetSets: 4, targetReps: "8–12"),
            Exercise(name: "Seitheben", muscle: "Seitliche Schulter", targetSets: 3, targetReps: "12–15"),
            Exercise(name: "Reverse Butterfly", muscle: "Hintere Schulter", targetSets: 3, targetReps: "12–15", imageName: "reverse_butterfly.jpg"),
            Exercise(name: "Scott-Curls", muscle: "Bizeps", targetSets: 3, targetReps: "10–12"),
            Exercise(name: "Kabelcurls", muscle: "Bizeps", targetSets: 3, targetReps: "10–12"),
            Exercise(name: "Trizepsdrücken", muscle: "Trizeps", targetSets: 3, targetReps: "10–12")
        ])
    ]
}

extension JSONEncoder {
    static var training: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return encoder
    }
}

extension JSONDecoder {
    static var training: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}