import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: TrainingStore
    @State private var showReset = false

    var body: some View {
        Form {
            Section("App") {
                LabeledContent("Version", value: "1.0")
                LabeledContent("Speicherung", value: "Lokal auf dem iPhone")
            }
            Section("Trainingsdaten") {
                Button("Alle Trainingsdaten löschen", role: .destructive) {
                    showReset = true
                }
            }
        }
        .navigationTitle("Einstellungen")
        .alert("Alle Trainings löschen?", isPresented: $showReset) {
            Button("Löschen", role: .destructive) { store.reset() }
            Button("Abbrechen", role: .cancel) {}
        } message: {
            Text("Dieser Schritt kann nicht rückgängig gemacht werden.")
        }
    }
}