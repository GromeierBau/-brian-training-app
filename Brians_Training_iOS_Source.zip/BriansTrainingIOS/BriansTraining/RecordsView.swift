import SwiftUI

struct RecordsView: View {
    @EnvironmentObject private var store: TrainingStore

    var body: some View {
        List {
            ForEach(allExerciseNames, id: \.self) { name in
                if let best = store.bestSet(for: name) {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(name).font(.headline)
                            Text("Persönlicher Bestwert").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text("\(best.weight.formatted()) kg × \(best.reps)")
                            .font(.headline)
                            .foregroundStyle(.red)
                    }
                }
            }

            if allExerciseNames.allSatisfy({ store.bestSet(for: $0) == nil }) {
                ContentUnavailableView(
                    "Noch keine Rekorde",
                    systemImage: "trophy",
                    description: Text("Nach dem ersten gespeicherten Training erscheinen sie hier.")
                )
            }
        }
        .navigationTitle("Rekorde")
    }

    private var allExerciseNames: [String] {
        Array(Set(store.plan.flatMap(\.exercises).map(\.name))).sorted()
    }
}