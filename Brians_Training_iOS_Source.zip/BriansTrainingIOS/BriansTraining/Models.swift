import Foundation

struct TrainingDay: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var exercises: [Exercise]

    init(id: UUID = UUID(), name: String, exercises: [Exercise]) {
        self.id = id
        self.name = name
        self.exercises = exercises
    }
}

struct Exercise: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var muscle: String
    var targetSets: Int
    var targetReps: String
    var imageName: String?
    var machineNote: String

    init(
        id: UUID = UUID(),
        name: String,
        muscle: String,
        targetSets: Int,
        targetReps: String,
        imageName: String? = nil,
        machineNote: String = ""
    ) {
        self.id = id
        self.name = name
        self.muscle = muscle
        self.targetSets = targetSets
        self.targetReps = targetReps
        self.imageName = imageName
        self.machineNote = machineNote
    }
}

struct CompletedSet: Identifiable, Codable, Hashable {
    let id: UUID
    var weight: Double
    var reps: Int

    init(id: UUID = UUID(), weight: Double = 0, reps: Int = 0) {
        self.id = id
        self.weight = weight
        self.reps = reps
    }
}

struct ExerciseLog: Identifiable, Codable, Hashable {
    let id: UUID
    var exerciseID: UUID
    var exerciseName: String
    var sets: [CompletedSet]
    var note: String

    init(id: UUID = UUID(), exerciseID: UUID, exerciseName: String, sets: [CompletedSet], note: String = "") {
        self.id = id
        self.exerciseID = exerciseID
        self.exerciseName = exerciseName
        self.sets = sets
        self.note = note
    }
}

struct WorkoutLog: Identifiable, Codable, Hashable {
    let id: UUID
    var dayID: UUID
    var dayName: String
    var date: Date
    var exercises: [ExerciseLog]

    init(id: UUID = UUID(), dayID: UUID, dayName: String, date: Date = .now, exercises: [ExerciseLog]) {
        self.id = id
        self.dayID = dayID
        self.dayName = dayName
        self.date = date
        self.exercises = exercises
    }
}