import SwiftUI

struct WorkoutView: View {
    @EnvironmentObject private var store: TrainingStore
    @Environment(\.dismiss) private var dismiss

    let day: TrainingDay
    @State private var logs: [ExerciseLog]

    init(day: TrainingDay) {
        self.day = day
        _logs = State(initialValue: day.exercises.map {
            ExerciseLog(
                exerciseID: $0.id,
                exerciseName: $0.name,
                sets: Array(repeating: CompletedSet(), count: $0.targetSets)
            )
        })
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(Array(day.exercises.enumerated()), id: \.element.id) { index, exercise in
                        ExerciseEntryCard(
                            exercise: exercise,
                            log: $logs[index],
                            lastLog: store.lastLog(for: exercise)
                        )
                    }
                    Button {
                        store.complete(WorkoutLog(dayID: day.id, dayName: day.name, exercises: logs))
                        dismiss()
                    } label: {
                        Label("Training speichern", systemImage: "checkmark.circle.fill")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .padding(.bottom, 30)
                }
                .padding()
            }
            .navigationTitle(day.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Abbrechen") { dismiss() }
                }
            }
        }
    }
}

private struct ExerciseEntryCard: View {
    let exercise: Exercise
    @Binding var log: ExerciseLog
    let lastLog: ExerciseLog?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let imageName = exercise.imageName,
               let image = UIImage(named: imageName) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 190)
                    .clipped()
                    .clipShape(RoundedRectangle(cornerRadius: 15))
            }

            HStack(alignment: .top) {
                VStack(alignment: .leading) {
                    Text(exercise.name).font(.title3.bold())
                    Text(exercise.muscle).font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
                Text("\(exercise.targetSets) × \(exercise.targetReps)")
                    .font(.caption.bold())
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.red.opacity(0.17), in: Capsule())
                    .foregroundStyle(.red)
            }

            if let lastLog {
                Text("Letztes Mal: " + lastLog.sets.map {
                    "\(format($0.weight)) kg × \($0.reps)"
                }.joined(separator: " · "))
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            HStack {
                Text("Satz").frame(width: 38)
                Text("kg").frame(maxWidth: .infinity)
                Text("Wdh.").frame(maxWidth: .infinity)
            }
            .font(.caption.bold())
            .foregroundStyle(.secondary)

            ForEach(log.sets.indices, id: \.self) { index in
                HStack {
                    Text("\(index + 1)").frame(width: 38)
                    TextField("0", value: $log.sets[index].weight, format: .number)
                        .keyboardType(.decimalPad)
                        .textFieldStyle(.roundedBorder)
                    TextField("0", value: $log.sets[index].reps, format: .number)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                }
            }

            TextField("Sitzhöhe, Griff, Notiz", text: $log.note, axis: .vertical)
                .textFieldStyle(.roundedBorder)
        }
        .padding()
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
    }

    private func format(_ value: Double) -> String {
        value.formatted(.number.precision(.fractionLength(value.rounded() == value ? 0 : 1)))
    }
}