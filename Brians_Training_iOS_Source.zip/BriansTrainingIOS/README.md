# Brians Training – iPhone-App

Das ist der vollständige SwiftUI-Quellcode für eine native iPhone-App.

## Funktionen

- 4er-Trainingssplit
- Gerätefotos aus deinem Studio
- Gewicht und Wiederholungen pro Satz
- Anzeige des letzten Trainings
- Verlauf
- persönliche Rekorde
- Notizen zu Sitzhöhe und Griff
- lokale Speicherung auf dem iPhone
- Dark Mode

## Installation auf einem iPhone

Apple erlaubt die Installation eigener iPhone-Apps nur über eine Signierung.

Du brauchst:

1. Einen Mac mit Xcode.
2. Eine kostenlose Apple-ID oder einen kostenpflichtigen Apple-Developer-Account.
3. XcodeGen, um das Xcode-Projekt zu erzeugen.

### XcodeGen installieren

Im Terminal auf dem Mac:

```bash
brew install xcodegen
```

### Projekt erzeugen

Im entpackten Ordner:

```bash
xcodegen generate
open BriansTraining.xcodeproj
```

### Auf das iPhone installieren

1. iPhone per Kabel mit dem Mac verbinden.
2. In Xcode dein iPhone als Ziel auswählen.
3. Unter „Signing & Capabilities“ deine Apple-ID auswählen.
4. Oben auf ▶︎ drücken.

Mit einer kostenlosen Apple-ID muss die App normalerweise nach sieben Tagen erneut signiert werden. Mit einem kostenpflichtigen Developer-Account bleibt sie länger installiert und kann über TestFlight verteilt werden.